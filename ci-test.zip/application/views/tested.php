<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Silsilah Bugis Makasar</title>
        <link rel="stylesheet" type="text/css" href="http://localhost/ci-test/assets/css/silsilah.css">
    </head>
    <body cz-shortcut-listen="true">
        <div class="outer-wrapper">
            <div class="row-wrapper center">
                <div class="main-wrapper main-head main-section">
                    <ul class="main-list">
                        <li class="with-pict king male">
                            <h3>La Wana</h3>
                            <span class="member-id" style="display: none">86</span>
                            <p class="label-datu">'Datu Botto'</p>
                            <p class="year">2009-2020</p>
                            <p class="label-title">Raja</p>
                        </li>
                        <li class="queen female">
                            <h3>I Mattingara</h3>
                            <span class="member-id" style="display: none">88</span>
                            <p class="label-datu">'Ar. Kuru' 'Ar. Palanro'</p>
                            <p class="year"></p>
                            <p class="label-title">Ratu</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row-wrapper center">
                <div class="main-wrapper child-wrapp child-section">
                    <div class="main-wrapper child-wrapp">
                        <ul class="child-list">
                            <li class="child male first">
                                <div class="wrapp">
                                    <h3>La Parellei </h3>
                                </div>
                                <div class="main-wrapper child-wrapp">
                                    <ul class="child-list">
                                        <li class="child female wife">
                                            <div class="wrapp">
                                                <h3>I Daruma  </h3>
                                            </div>
                                            <div class="main-wrapper child-wrapp">
                                                <ul class="child-list">
                                                    <li class="child male first">
                                                        <div class="wrapp">
                                                            <h3>Andi Amat </h3>
                                                        </div>
                                                        <div class="main-wrapper child-wrapp">
                                                            <ul class="child-list">
                                                                <li class="child male first">
                                                                    <div class="wrapp">
                                                                        <h3>Andi Kacalak </h3>
                                                                    </div>
                                                                    <div class="main-wrapper child-wrapp">
                                                                        <ul class="child-list">
                                                                            <li class="child male first">
                                                                                <div class="wrapp">
                                                                                    <h3>Andi Maramat </h3>
                                                                                </div>
                                                                                <div class="main-wrapper child-wrapp">
                                                                                    <ul class="child-list">
                                                                                        <li class="child female wife">
                                                                                            <div class="wrapp">
                                                                                                <h3>Andi Mapparola </h3>
                                                                                            </div>
                                                                                            <div class="main-wrapper child-wrapp">
                                                                                                <ul class="child-list">
                                                                                                    <li class="child male first">
                                                                                                        <div class="wrapp">
                                                                                                            <h3>Andi Tessioja </h3>
                                                                                                        </div>
                                                                                                        <div class="main-wrapper child-wrapp">
                                                                                                            <ul class="child-list"></ul>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                    <li class="child male first">
                                                                                                        <div class="wrapp">
                                                                                                            <h3>Andi Hakka </h3>
                                                                                                        </div>
                                                                                                        <div class="main-wrapper child-wrapp">
                                                                                                            <ul class="child-list"></ul>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                    <li class="child male first">
                                                                                                        <div class="wrapp">
                                                                                                            <h3>Andi Sapinah </h3>
                                                                                                        </div>
                                                                                                        <div class="main-wrapper child-wrapp">
                                                                                                            <ul class="child-list"></ul>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                    <li class="child male first">
                                                                                                        <div class="wrapp">
                                                                                                            <h3>Andi Maula </h3>
                                                                                                        </div>
                                                                                                        <div class="main-wrapper child-wrapp">
                                                                                                            <ul class="child-list">
                                                                                                                <li class="child female wife">
                                                                                                                    <div class="wrapp">
                                                                                                                        <h3>Andi Nani </h3>
                                                                                                                    </div>
                                                                                                                    <div class="main-wrapper child-wrapp">
                                                                                                                        <ul class="child-list">
                                                                                                                            <li class="child male first">
                                                                                                                                <div class="wrapp">
                                                                                                                                    <h3>Andi Ervin </h3>
                                                                                                                                </div>
                                                                                                                                <div class="main-wrapper child-wrapp">
                                                                                                                                    <ul class="child-list"></ul>
                                                                                                                                </div>
                                                                                                                            </li><li class="child male first"><div class="wrapp"><h3>Andi Aswin </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Abdullah </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div></li></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Amir Syarifuddin </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Sulolipu </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child female wife"><div class="wrapp"><h3>Andi Asma </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child male first"><div class="wrapp"><h3>Andi Sadat </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div></li></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Kacce </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div></li></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Unru </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child female wife"><div class="wrapp"><h3>Unknown </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child male first"><div class="wrapp"><h3>Andi Ippung </h3></div>
                                                                                                                                                <div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div></li></ul></div></li></ul></div></li><li class="child female wife"><div class="wrapp"><h3>Unknown </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child male first"><div class="wrapp"><h3>Andi Uneng </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child female wife"><div class="wrapp"><h3>Farida </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child male first"><div class="wrapp"><h3>Andi Mauraga </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Uneda </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Nurul </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div></li></ul></div></li></ul></div></li></ul></div></li></ul></div></li></ul></div></li><li class="child male first"><div class="wrapp"><h3>La Ippung </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child female wife"><div class="wrapp"><h3>I Tessioja </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child male first"><div class="wrapp"><h3>Andi Kacalak </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li><li class="child male first"><div class="wrapp"><h3>Andi Dunnahi </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child female wife"><div class="wrapp"><h3>Unknown </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"><li class="child male first"><div class="wrapp"><h3>Andi Pananong </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div></li></ul></div></li></ul></div></li></ul></div></li><li class="child male first"><div class="wrapp"><h3>La Uneng </h3></div><div class="main-wrapper child-wrapp"><ul class="child-list"></ul></div></li></ul></div>
                </div>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>

        <script>
            $(document).ready(function () {
                mainSection();
            });

            function mainSection() {
                var url = "http://localhost/ci-test/index.php/silsilah/test";
                $.get(url, null, function (data) {
                    $(".main-section").html(data);
                    $(".member-id").each(function () {
                        childSection($(this).html());
                    });
                });
            }
            function childSection(parentId) {
                var url = "http://localhost/ci-test/index.php/silsilah/anoterMember/" + parentId;
                $.get(url, null, function (data) {
                    $(".child-section").html(data);
                });
            }
        </script>

    </body></html>