<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Silsilah
 *
 * @author sigit
 */
class Silsilah extends CI_Controller {

//put your code here

    function addMember() {
        $data['parent'] = $this->db->query("SELECT * FROM member_detail WHERE parent_id IS NULL ORDER BY parent_id, member_id ASC")->result();
        $this->load->view('add-member', $data);
    }

    function proc_add_member() {
        $parentId = empty($this->input->post('parent_id')) ? null : $this->input->post('parent_id');
        $nama = $this->input->post('nama');
        $sebagai = $this->input->post('sebagai');
        $member_img = $this->input->post('member_img');
        $berkuasaPhoto = $this->input->post('berkuasa-pada');
        $gelar = $this->input->post('gelar');
        $jk = $this->input->post("jk");

//        echo $parentId;


        $dataInsertMember = ['parent_id' => $parentId, 'nama' => $nama, 'member_img' => $member_img, "sebagai" => $sebagai, 'berkuasa_pada' => $berkuasaPhoto, 'gelar' => $gelar];
        $res = $this->member->insertDb('member_detail', $dataInsertMember);

        if ($res > 0) {
            redirect('silsilah/addmember', 'refresh');
        } else {
            echo "Somethin' wrong";
        }
    }

    function getFamilyTree() {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        $res = $this->db->query("SELECT * FROM member_detail ORDER BY member_id")->result();
        $data = [];
        foreach ($res as $r) {
            $tmp = [];
            $tmp['memberId'] = $r->member_id;
            $tmp['parentId'] = $r->parent_id;
            $tmp['nama'] = $r->nama;
            $tmp['sebagai'] = $r->sebagai;
            $tmp['berkuasa_pada'] = $r->berkuasa_pada;
            $tmp['jk'] = $r->jk;
            $tmp['gelar'] = $r->gelar;

            array_push($data, $tmp);
        }

        echo json_encode($data);
    }

    function showFamilyTree() {
        $this->load->view("tree-view");
    }

    function showFamilyTreeMobile() {
        $this->load->view("tree-view-mobile");
    }

    function showFamilyTreeDesktop() {
        $this->load->view("tree-view-desktop");
    }

    function resetTable() {
        $this->db->empty_table('member_detail');
        redirect('silsilah/addmember', 'refresh');
    }

    function deleteNode($node) {
        $where = ['member_id' => $node];
        $check = $this->db->query("SELECT * FROM member_detail WHERE parent_id IN ('$node')");
        $delete = $this->member->deleteDb('member_detail', $where);
        if ($delete > 0) {
            if ($check->num_rows() > 0) {
                $parentId = ['parent_id' => $node];
                $deleteNode = $this->member->deleteDb('member_detail', $parentId);
                if ($deleteNode > 0) {
                    echo json_encode(['code' => 200]);
                    return;
                }
            }
            echo json_encode(['code' => 200]);
        }
    }

    function updateNode() {
        $memberId = $this->input->get("member-id");
        $selectedParent = $this->input->post("selected-parent-id");

        $nama = $this->input->post('nama');
        $sebagai = $this->input->post('sebagai');
        $berkuasaPada = $this->input->post('berkuasa-pada');
        $gelar = $this->input->post('gelar');
        $jk = $this->input->post("jk");

        $where = ['member_id' => $memberId];

        $dataupdate = ['parent_id' => $selectedParent, 'nama' => $nama, 'sebagai' => $sebagai, 'berkuasa_pada' => $berkuasaPada, 'gelar' => $gelar, 'jk' => $jk];

        $update = $this->member->updateDb('member_detail', $dataupdate, $where);
        if ($update > 0) {
            $this->output->set_header('refresh:2; url=' . site_url("silsilah/showFamilyTree"));
            echo "Update berhasil. Anda akan diarahkan ke halaman family tree dalam 5 detik";
        } else {
            echo "something wrong";
        }
    }

    function formUpdate() {
        $parentId = $this->input->get("member-id");
        $data['parent'] = $this->db->query("SELECT * FROM member_detail WHERE parent_id IS NULL ORDER BY parent_id, member_id ASC")->result();
        $data['member'] = $this->db->query("SELECT * FROM member_detail WHERE member_id IN ('$parentId')")->row();
//        echo "SELECT * FROM member_detail WHERE member_id IN ('$parentId')";
        $parentIdBefore = $data['member']->parent_id;
        $data['before'] = $this->db->query("SELECT * FROM member_detail WHERE member_id IN ('$parentIdBefore')")->row();
//        echo "SELECT * FROM member_detail WHERE parent_id IN ('$parentIdBefore')";
        $this->load->view('edit-member', $data);
    }

    function treeTest() {
        $this->load->view('tree-test');
    }

    function test() {
        echo "<ul class='main-list'>";
        $raja = $this->db->query("SELECT * FROM member_detail WHERE parent_id IS NULL OR sebagai IN ('ratu')")->result();
        foreach ($raja as $r) {
            if ($r->sebagai == "Raja") {
                echo "<li class='with-pict king male'>";
                echo '<div class="pict-wrapp">
                                <img src="' . base_url('assets/') . 'img/male.jpeg" alt="Raja">
                            </div>';
            } else {
                echo "<li class='queen female'>";
            }
            echo "<h3>$r->nama</h3>";
            echo "<span class='member-id' style='display: none'>$r->member_id</span>";
            echo '<p class="label-datu">' . $r->gelar . '</p>';
            echo '<p class="year">' . $r->berkuasa_pada . '</p>';
            echo '<p class="label-title">' . $r->sebagai . '</p>';
            if (empty($r->member_id)) {
                echo "</li>";
            }
        }
        echo "</ul>";
    }

    function anoterMember($parentId = null, $last = false) {
        $anoterMember = $this->db->query("SELECT * FROM member_detail WHERE parent_id IN ('$parentId') AND sebagai NOT IN ('ratu', 'raja') ORDER BY member_id");

        $count = $anoterMember->num_rows();
        foreach ($anoterMember->result() as $key => $an) {
            if ($an->jk == "Laki-Laki" && $an->generasi == 1) {
                if ($key == $count - 1) {
                    $this->anoterMember($an->member_id, true);
                    echo "<li class='child male last' style='color:red'>";
                    echo "<div class='wrapp'>";
                    echo "<h3>$an->nama </h3>";
                    echo '<p class="label-title">' . $an->sebagai . '</p>';
                    echo "</div>";
                    echo "</li>";
                } else if ($key == 0) {
                    echo "<li class='child male first'>";
                    echo "<div class='wrapp'>";
                    echo "<h3>$an->nama </h3>";
                    echo '<p class="label-title">' . $an->sebagai . '</p>';
                    echo "</div>";
                    $this->anoterMember($an->member_id);
                    echo "</li>";
                } else {
                    echo "<li class='child male '>";
                    echo "<div class='wrapp'>";
                    echo "<h3>$an->nama </h3>";
                    echo '<p class="label-title">' . $an->sebagai . '</p>';
                    echo "</div>";
                    $this->anoterMember($an->member_id);
                    echo "</li>";
                }
            } else if ($an->jk == "Laki-Laki") {
                echo '<div class="main-wrapper child-wrapp">';
                echo "<ul class='child-list'>";
                if ($count == 1) {
                    echo "<li class='child male'>";
                    echo "<div class='wrapp'>";
                    echo "<h3>$an->nama </h3>";
                    echo '<p class="label-title">' . $an->sebagai . '</p>';
                    echo "</div>";
                    $this->anoterMember($an->member_id);
                    echo "</li>";
                    echo "</ul>";
                    echo "</div>";
                } else {
                    if ($key == 0) {
                        echo "<li class='child male first'>";
                        echo "<div class='wrapp'>";
                        echo "<h3>$an->nama </h3>";
                        echo '<p class="label-title">' . $an->sebagai . '</p>';
                        echo "</div>";
                        $this->anoterMember($an->member_id);
                        echo "</li>";
                        echo "</ul>";
                        echo "</div>";
                    } else if ($key == $count - 1) {
                        $this->anoterMember($an->member_id, true);
                        echo "<li class='child male last' style='color: red'>";
                        echo "<div class='wrapp'>";
                        echo "<h3>$an->nama</h3>";
                        echo '<p class="label-title">' . $an->sebagai . '</p>';
                        echo "</div>";
                        echo "</li>";
                        echo "</ul>";
                        echo "</div>";
                    } else {
                        echo "<li class='child male '>";
                        echo "<div class='wrapp'>";
                        echo "<h3>$an->nama </h3>";
                        echo '<p class="label-title">' . $an->sebagai . '</p>';
                        echo "</div>";
                        $this->anoterMember($an->member_id);
                        echo "</li>";
                        echo "</ul>";
                        echo "</div>";
                    }
                }
            } else if ($an->jk == "Perempuan" && $an->sebagai == "Istri") {
                $countMember = $this->db->query("SELECT COUNT(*) as member FROM member_detail WHERE parent_id IN ('" . $an->member_id . "') AND sebagai NOT IN ('ratu', 'raja') ORDER BY member_id");
                $counts = $countMember->row()->member;
                if ($last == true) {
                    if ($counts > 1) {
                        echo "<li class='child female wife last'>";
                    } else {
                        echo "<li class='child female wife last tunggal'>";
                    }
                } else {
                    if ($counts > 1) {
                        echo "<li class='child female wife first'>";
                    } else {
                        echo "<li class='child female wife tunggal'>";
                    }
                }
                echo "<div class='wrapp' style=''>";
                echo "<h3>$an->nama </h3>";
                echo '<p class="label-title">' . $an->sebagai . '</p>';
                echo "</div>";
                $this->anoterMember($an->member_id);
                echo "</li>";
            } else if ($an->jk == "Perempuan" && $an->sebagai == "Anak") {
                echo '<div class="main-wrapper child-wrapp">';
                echo "<ul class='child-list'>";
                if ($count == 0) {
                    echo "<li class='child female'>";
                } else {
                    if ($key == 0) {
                        echo "<li class='child female first'>";
                    } else if ($key == $count - 1) {
                        echo "<li class='child female last'>";
                    } else {
                        echo "<li class='child female '>";
                    }
                }
                echo "<div class='wrapp'>";
                echo "<h3>$an->nama </h3>";
                echo '<p class="label-title">' . $an->sebagai . '</p>';
                echo "</div>";
                $this->anoterMember($an->member_id);
                echo "</li>";
                echo "</ul>";
                echo "</div>";
            }
        }
    }

}
